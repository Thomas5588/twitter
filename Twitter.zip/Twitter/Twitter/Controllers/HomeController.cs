﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Twitter.Models;

namespace Twitter.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public ActionResult ProfileTimeLine()
        {
            return View();
        }

        [HttpPost]
        public async System.Threading.Tasks.Task<ActionResult> ProfileTimeLine(Options options)
        {
            using (var client = new HttpClient())
            {
                //client.BaseAddress = new Uri("http://localhost:55587/");

                //var url = "https://publish.twitter.com/oembed?url=https://twitter.com/Jerald82468282?ref_src=twsrc%5Etfw";

                var url = "https://publish.twitter.com/oembed?url=https://twitter.com/TwitterDev";

                HttpResponseMessage response = await client.GetAsync(url);
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();

            }
            return View();
        }
    }
}
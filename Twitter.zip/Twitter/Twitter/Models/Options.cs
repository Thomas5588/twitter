﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Twitter.Models
{
    public class Options
    {
        public Chrome Chrome { get; set; }

        public Themes Themes { get; set; }
    }

    public enum Chrome
    {
        noheader,
        nofooter,
        noborders,
        noscrollbar,
        transparent
    }

    public enum Themes
    {
        Dark,
        Ligth
    }
}
﻿$(document).ready(function () {
    $("#Chrome").addClass("form-control");
    $("#Themes").addClass("form-control");

    //$("#submit").click(function () {
    //    var selectedText = $("#Chrome").find("option:selected").text();
    //    var selectedValue = $("#Chrome").val();

    //    alert($("a .twitter-timeline").attr("id"));
    //    //if (selectedText === "noheader") {

    //    //    if ($("#timeLine").attr("id")) {
    //    //        alert('no');
    //    //    }
    //    //}
    //});
});
